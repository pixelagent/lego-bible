'''
Copyright (C) 2020 Nicolas Jarraud
mecabricks@gmail.com

Created by Nicolas jarraud

    License of the software is non-exclusive, non-transferrable
    and is granted only to the original buyer. Buyers do not own
    any Product and are only licensed to use it in accordance
    with terms and conditions of the applicable license. The Seller
    retains copyright in the software purchased or downloaded by any Buyer.

    The Buyer may not resell, redistribute, or repackage the Product
    without explicit permission from the Seller.

    Any Product, returned to Mecabricks and (or) the Seller in accordance
    with applicable law for whatever reason must be destroyed by the Buyer
    immediately. The license to use any Product is revoked at the time
    Product is returned. Product obtained by means of theft or fraudulent
    activity of any kind is not granted a license.
'''

bl_info = {
    "name": "Mecabricks Lite",
    "description": "Import Mecabricks 3D Models",
    "author": "Nicolas Jarraud",
    "version": (3, 1, 4),
    "blender": (2, 80, 0),
    "location": "File > Import-Export",
    "warning": "",
    "wiki_url": "www.mecabricks.com",
    "category": "Import-Export"
}

import bpy
import os

from .loaders.SceneLoader import SceneLoader
from .loaders.utils import find_node

# ------------------------------------------------------------------------------
# Import Mecabricks scene
# ------------------------------------------------------------------------------
def import_mecabricks(self, context, filepath, settings):
    # Check Blender version
    if bpy.app.version < (2, 80, 0):
        self.report({'ERROR'}, 'This add-on requires Blender 2.80 or greater.')
        return {'FINISHED'}

    # Ensure that viewport is in object mode
    if bpy.context.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')

    # Deselect all
    bpy.ops.object.select_all(action='DESELECT')

    # Create new collection
    collection_name = os.path.splitext(os.path.basename(filepath))[0]
    collection = bpy.data.collections.new(collection_name)
    bpy.context.scene.collection.children.link(collection)

    # Addon directory path
    addon_path = os.path.dirname(os.path.realpath(__file__))

    # Load scene
    loader = SceneLoader(addon_path, settings['logos'])
    scene = loader.load(filepath, collection)

    # Focus viewports
    focus_viewports(scene['parts'])

    # Deselect all
    bpy.ops.object.select_all(action='DESELECT')

    # Select empty
    scene['empty'].select_set(state=True)
    bpy.context.view_layer.objects.active = scene['empty']

    return {'FINISHED'};

# ------------------------------------------------------------------------------
# Focus viewport cameras on added elements
# ------------------------------------------------------------------------------
def focus_viewports(objects):
    # Select added objects
    for object in objects:
        object.select_set(state=True)

    # Focus viewport on scene for all 3D views
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D' and area.spaces[0].region_3d.view_perspective != 'CAMERA':
            ctx = bpy.context.copy()
            ctx['area'] = area
            ctx['region'] = area.regions[-1]
            bpy.ops.view3d.view_selected(ctx)

# ------------------------------------------------------------------------------
# Import panel
# ------------------------------------------------------------------------------
from bpy_extras.io_utils import ImportHelper
from bpy.props import StringProperty, BoolProperty
from bpy.types import Operator

class IMPORT_OT_zmbx(Operator, ImportHelper):
    bl_idname = 'import_mecabricks.zmbx'
    bl_description = 'Import from Mecabricks file format (.zmbx)'
    bl_label = "Import ZMBX"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_options = {'UNDO'}

    filepath: StringProperty(
        name="input file",
        subtype='FILE_PATH'
    )

    filename_ext = ".zmbx"

    filter_glob: StringProperty(
        default = "*.zmbx",
        options = {'HIDDEN'},
    )

    # Logos
    setting_logos: BoolProperty(
            name="Logo on studs",
            description="Display brand logo on top of studs",
            default=True,
            )

    def draw(self, context):
        layout = self.layout

        # Geometry
        box = layout.box()
        box.label(text='Geometry Options: ', icon="OUTLINER_DATA_MESH" )

        # Logos
        row = box.row()
        row.prop(self.properties, 'setting_logos')

    def execute(self, context):
        settings = {
            'logos': self.setting_logos
        }

        return import_mecabricks(self, context, self.filepath, settings)

# ------------------------------------------------------------------------------
# Register / Unregister
# ------------------------------------------------------------------------------
# Import menu
def menu_func(self, context):
    self.layout.operator(IMPORT_OT_zmbx.bl_idname, text = 'Mecabricks (.zmbx)')

def register():
    bpy.utils.register_class(IMPORT_OT_zmbx)
    bpy.types.TOPBAR_MT_file_import.append(menu_func)

def unregister():
    bpy.utils.unregister_class(IMPORT_OT_zmbx)
    bpy.types.TOPBAR_MT_file_import.remove(menu_func)

if __name__ == "__main__":
    register()
